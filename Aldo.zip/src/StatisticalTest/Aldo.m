load("aldo.mat"); 
Reg_Prom_LAB_test = (mtx);% Sin encabezado

%[h,p] = lillietest(Reg_Prom_LAB_test(:,4),'Alpha',0.05)
[H, pValue, W] = swtest(mtx(:,1), 0.05)
[H, pValue, W] = swtest(mtx(:,2), 0.05)
[H, pValue, W] = swtest(mtx(:,3), 0.05)
[H, pValue, W] = swtest(mtx(:,4), 0.05)



%%  kruskalwallis
     vecinos = {'DeepGA CNN and 1 PMF CIE L*a*b*','DeepGA CNN and 3 PMF CIE L*a*b*', 'DeepGA CNN and 1 PMF HSI','DeepGA CNN and 3 PMF HSI'};
    
     [p,tbl,stats]= kruskalwallis(mtx,vecinos);
     figure;
     c = multcompare(stats);
     %[vecinos(c(:,1))',vecinos(c(:,2))', num2cell(c(:,6:6))]
disp('dd')